﻿// SAMPLE: CommonAssemblyInfo
using System.Reflection;
using System.Runtime.InteropServices;
[assembly: AssemblyDescription("1.1.0.51709")]
[assembly: AssemblyProduct("FubuCore")]
[assembly: AssemblyCopyright("Copyright 2008-2013 Jeremy D. Miller, Josh Arnold, Joshua Flanagan, et al. All rights reserved.")]
[assembly: AssemblyTrademark("83be3ac3fe927bacc2e81b1197ae5bc0508802f3")]
[assembly: AssemblyVersion("1.1.0.0")]
[assembly: AssemblyFileVersion("1.1.0.51709")]
[assembly: AssemblyInformationalVersion("1.1.0.0")]
// ENDSAMPLE